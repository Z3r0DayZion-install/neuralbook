#!/usr/bin/env python3
"""
Example 4: Encryption & Decryption
===================================
Demonstrates the cryptographic features of NeuralBook.

This example shows:
- Deriving encryption keys from seeds
- Encrypting content with AES-256-GCM
- Verifying integrity
- Unique IVs per message

Requirements:
  pip install neuralbook

Usage:
  python 04_encryption.py
"""

import sys
import secrets
from neuralbook.encryption import derive_key, encrypt_content, decrypt_content

def main():
    """Demonstrate encryption and decryption."""
    
    print("=" * 60)
    print("NeuralBook: Encryption Example")
    print("=" * 60)
    
    # 1. Generate seed
    print("\n[1] Generating encryption seed...")
    seed = secrets.token_bytes(48)  # 48-byte seed (recommended for AES-256)
    print(f"  ✓ Seed generated: {seed.hex()[:32]}... ({len(seed)} bytes)")
    
    # 2. Derive encryption key
    print("\n[2] Deriving AES-256 key from seed...")
    key = derive_key(seed, iterations=100000)
    print(f"  ✓ Key derived: {key.hex()[:32]}... ({len(key)} bytes)")
    print(f"    Algorithm: AES-256-GCM")
    print(f"    Iterations: 100,000 (NIST recommended minimum)")
    
    # 3. Prepare content
    print("\n[3] Preparing content for encryption...")
    original_content = b"""
This is a confidential chapter from a NeuralBook.

It contains sensitive information that will be protected with:
- AES-256-GCM authenticated encryption
- Unique random IV for each message
- 128-bit authentication tag for integrity verification

The reader can verify they have the genuine, unmodified content.
""".strip()
    
    print(f"  ✓ Content prepared: {len(original_content)} bytes")
    
    # 4. Encrypt content
    print("\n[4] Encrypting content...")
    iv, ciphertext = encrypt_content(original_content, key)
    print(f"  ✓ Encryption complete:")
    print(f"    IV: {iv.hex()} (96 bits, random)")
    print(f"    Ciphertext: {ciphertext.hex()[:32]}... ({len(ciphertext)} bytes)")
    print(f"    (includes 128-bit authentication tag)")
    
    # 5. Demonstrate tampering detection
    print("\n[5] Testing integrity verification...")
    
    # Try to decrypt with valid ciphertext
    try:
        decrypted = decrypt_content(iv, ciphertext, key)
        print(f"  ✓ Successfully decrypted with valid ciphertext")
        print(f"    Length: {len(decrypted)} bytes")
    except Exception as e:
        print(f"  ✗ Decryption failed: {e}")
        return 1
    
    # Verify content matches
    assert decrypted == original_content, "Decrypted content does not match!"
    print(f"  ✓ Decrypted content matches original")
    
    # Try with corrupted ciphertext (should fail)
    print("\n  Testing with corrupted ciphertext...")
    corrupted_ciphertext = bytes([(b ^ 0xFF) if i < 16 else b for i, b in enumerate(ciphertext)])  # Flip first 16 bytes
    
    try:
        decrypt_content(iv, corrupted_ciphertext, key)
        print(f"  ✗ ERROR: Should have failed with corrupted ciphertext!")
        return 1
    except Exception as e:
        print(f"  ✓ Integrity check failed as expected: {type(e).__name__}")
        print(f"    This proves the content has not been tampered with.")
    
    # 6. Multiple messages with same key
    print("\n[6] Encrypting multiple messages with same key...")
    
    messages = [
        b"First chapter",
        b"Second chapter",
        b"Third chapter",
    ]
    
    encrypted_messages = []
    for i, msg in enumerate(messages, 1):
        iv, ct = encrypt_content(msg, key)
        encrypted_messages.append((iv, ct))
        print(f"  ✓ Message {i}: IV={iv.hex()[:16]}... (unique for each message)")
    
    print(f"\n  Each message has a unique IV, preventing patterns even with")
    print(f"  identical plaintext or the same encryption key.")
    
    # 7. Summary
    print("\n" + "=" * 60)
    print("Encryption Demo Complete!")
    print("=" * 60)
    print("\nKey Takeaways:")
    print("  🔐 AES-256-GCM provides both confidentiality and authenticity")
    print("  🎲 Unique IVs prevent cryptographic patterns")
    print("  ✓ Authentication tags detect any tampering")
    print("  🔑 Keys are derived from seeds using PBKDF2 with 100k iterations")
    print("\nNeuralBook uses these techniques to ensure:")
    print("  - Content cannot be read without authorization")
    print("  - Content cannot be modified without detection")
    print("  - Each reader gets a unique encrypted version")
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
